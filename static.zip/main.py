from flask import Flask,render_template,request,redirect,session
import mysql.connector
import  os
app=Flask(__name__)
app.secret_key=os.urandom(24)



conn=mysql.connector.connect(host="remotemysql.com",user="eVRsRfH5PE",password="eVRsRfH5PE",database="eVRsRfH5PE")
cursor=conn.cursor()



@app.route('/')
def login3():
    return  render_template('login3.html')
@app.route('/login')
def about():
    return render_template('login.html')


@app.route('/home')
def home():
    if 'userid' in session:
        return render_template('home.html')
    else:
        return render_template('/')

@app.route('/login_validation',methods=['POST'])
def login_validation():
    email=request.form.get('email')
    password=request.form.get('password')
    cursor.execute("""select * from 'users' WHERE 'email' LIKE '{}' AND 'password' LIKE '{}'""".format(email,password))
    cursor.fetchall()
    print(users)
    if len(users)>0:
        session['userid']=users[0][0]
        return redirect('home.html')
    else:
        return redirect('/')
@app.route('/add_user',methods='POST')
def add_user():
    name=request.form.get('uname')
    email=request.form.get('uemail')
    password=request.form.get('password')
    cursor.execute("""INSERT INTO 'users'('userid',''name','email','password') VALUES (NULL,'{}','{}','{}')""".format(name,email,password))
    conn.commit()
    cursor.execute("""select * from 'users' WHERE 'email' LIKE '{}'""".format(email))
    myuser=cursor.fetchall()
    session['userid']=myuser[0][0]


    return "User registered Successfully"


if __name__=="__main__":
    app.run(debug=True)